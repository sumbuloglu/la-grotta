# Cave Restaurant
Android restaurant exploration and cooking game. All interface text is English.

## Screens
Home, Menu, Gallery, Kitchen.

## Gameplay
Select the exact ingredients shown in the recipe, prepare the dish, then serve it. Preparation earns 20 points. Service earns 80 points plus a streak bonus of 10–50 points. Wrong preparation deducts 10 points (minimum zero) and resets the streak. Best score is stored on device. Starting a new shift resets the current run after confirmation.

## Build
Use Android Studio with SDK 35 and Java 17, or Gradle 8.9: `gradle assembleDebug`.
The included GitHub Actions workflow builds the APK and uploads it as an artifact.

## Status
Source prepared. Android compilation, emulator execution, and visual verification are pending Android SDK setup. The workflow has not been run. Food photographs are pending; the original AI-created cave interior is included.
